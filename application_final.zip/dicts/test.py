import os
mon_fichier1 = open("positive.yml", "r")
contenu = mon_fichier1.readlines()
mon_fichier1.close()
mon_fichier2 = open("fichier.txt", "w")
for line in contenu:
    mon_fichier2.write(line.rstrip()+': [positive]\n')
mon_fichier2.close()
